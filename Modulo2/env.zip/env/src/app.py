from datetime import *
from dateutil.relativedelta import *
now = datetime.now()
print(now)

now = now + relativedelta(month=1, day=4, hour=10, minute=10, second=10)

print(now)